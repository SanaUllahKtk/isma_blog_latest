<x-site.layout>
    <section class="choose-area pt-120 pb-120 p-relative" style="background:#f5f8fa;">

        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="choose-wrap">
                        <div class="section-title w-title left-align mb-35 wow fadeInDown animated"
                            data-animation="fadeInDown animated" data-delay=".2s">
                            <h2>Presidents Message</h2>
                        </div>
                        <div class="choose-content wow fadeInUp animated" data-animation="fadeInDown animated"
                            data-delay=".2s">
                            <p>SPRINGS magazine is 60 years old!

                                I was trying to write this message in my head as Sherri and I watched our grandson Cole,
                                who is almost 2, for a few hours. As I watched him explore his world, trying to take the
                                wheels off of everything (just like his dad) or touching the bugs he found crawling
                                around, it made me reflect that SPRINGS at one time was 2 years old, exploring its world
                                in much the same way.

                                It was indeed a group of manufacturers trying their best to explore their world with the
                                latest technology and understanding of their day. Sharing their knowledge and learning
                                experiences through articles and papers in the magazine was the natural outcome. As I
                                continued watching my grandson, it made me realize that we are still doing
                                this…exploring our world with the latest understanding and technology of our day.
                                Discovering more and more of God’s design that we call the world of physics or the best
                                business or financial practices, and then relating those discoveries to our customers
                                and peers.

                                In essence, this is what SMI is all about, and will continue to be: a group of
                                manufacturers with the best interest of the industry at heart, working together, and
                                sharing information that is relevant and crucial for all springmakers.

                                The main focus of this edition of SPRINGS is “Managing our Customer’s Expectations.”
                                This at best is an ever-changing list, and right now a true challenge with some of the
                                headwinds we are facing in our industry and manufacturing as a whole. I hope you will
                                find this information interesting and right for this moment.

                                In closing, collaboration to a common solution is one of the most rewarding parts of any
                                job, so continuing to do this amongst this team of manufacturers will continue to be our
                                goal. I hope that the SMI and SPRINGS magazine continues for another 60 years, but that
                                my friends, is up to us.

                                Let’s Go!

                                Live a crazy good day and God Bless!</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</x-site.layout>
