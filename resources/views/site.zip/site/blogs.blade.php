<x-site.layout>
    <section id="blog" class="blog-area  p-relative pt-120 pb-90">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8 col-lg-10">
                    <div class="section-title text-center mb-80 wow fadeInDown animated"
                        data-animation="fadeInDown animated" data-delay=".2s">
                        <span>New Every Day</span>
                        <h2>Latest News</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="single-post mb-30 wow fadeInUp animated" data-animation="fadeInDown animated"
                        data-delay=".2s">
                        <div class="blog-thumb">
                            <a href="/blog/making-distributed-team"><img src="/site/img/blog/blog_img01.jpg"
                                    alt="img"></a>
                        </div>
                        <div class="blog-content">
                            <div class="b-meta mb-20">
                                <ul>
                                    <li><a href="#">By admin .</a></li>
                                    <li><a href="#">20 jan 2019 .</a></li>
                                    <li><a href="#" class="corpo">Corporate</a></li>
                                </ul>
                            </div>
                            <h4><a href="/blog/making-distributed-team">Making Distribut Product Team
                                    Work More With Monday</a></h4>
                            <p>Lorem ipsum dolor sit amet consectetur adipisi
                                cing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <a href="/blog/making-distributed-team" class="btn blog-btn">Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="single-post active mb-30 wow fadeInUp animated" data-animation="fadeInDown animated"
                        data-delay=".2s">
                        <div class="blog-thumb">
                            <a href="/blog/making-distributed-team"><img src="/site/img/blog/blog_img02.jpg"
                                    alt="img"></a>
                        </div>
                        <div class="blog-content">
                            <div class="b-meta mb-20">
                                <ul>
                                    <li><a href="#">By admin .</a></li>
                                    <li><a href="#">20 jan 2019 .</a></li>
                                    <li><a href="#" class="corpo">Corporate</a></li>
                                </ul>
                            </div>
                            <h4><a href="/blog/making-distributed-team">Monthly Web Development Upto Cost Of JavaScript
                                    Ethics</a>
                            </h4>
                            <p>Lorem ipsum dolor sit amet consectetur adipisi
                                cing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <a href="/blog/making-distributed-team" class="btn blog-btn">Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="single-post mb-30 wow fadeInUp animated" data-animation="fadeInDown animated"
                        data-delay=".2s">
                        <div class="blog-thumb">
                            <a href="/blog/making-distributed-team"><img src="/site/img/blog/blog_img03.jpg"
                                    alt="img"></a>
                        </div>
                        <div class="blog-content">
                            <div class="b-meta mb-20">
                                <ul>
                                    <li><a href="#">By admin .</a></li>
                                    <li><a href="#">20 jan 2019 .</a></li>
                                    <li><a href="#" class="corpo">Corporate</a></li>
                                </ul>
                            </div>
                            <h4><a href="/blog/making-distributed-team">User Experience Psychology And Performance
                                    Smashing</a></h4>
                            <p>Lorem ipsum dolor sit amet consectetur adipisi
                                cing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <a href="/blog/making-distributed-team" class="btn blog-btn">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="single-post mb-30 wow fadeInUp animated" data-animation="fadeInDown animated"
                        data-delay=".2s">
                        <div class="blog-thumb">
                            <a href="/blog/making-distributed-team"><img src="/site/img/blog/blog_img01.jpg"
                                    alt="img"></a>
                        </div>
                        <div class="blog-content">
                            <div class="b-meta mb-20">
                                <ul>
                                    <li><a href="#">By admin .</a></li>
                                    <li><a href="#">20 jan 2019 .</a></li>
                                    <li><a href="#" class="corpo">Corporate</a></li>
                                </ul>
                            </div>
                            <h4><a href="/blog/making-distributed-team">Making Distribut Product Team
                                    Work More With Monday</a></h4>
                            <p>Lorem ipsum dolor sit amet consectetur adipisi
                                cing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <a href="/blog/making-distributed-team" class="btn blog-btn">Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="single-post active mb-30 wow fadeInUp animated" data-animation="fadeInDown animated"
                        data-delay=".2s">
                        <div class="blog-thumb">
                            <a href="/blog/making-distributed-team"><img src="/site/img/blog/blog_img02.jpg"
                                    alt="img"></a>
                        </div>
                        <div class="blog-content">
                            <div class="b-meta mb-20">
                                <ul>
                                    <li><a href="#">By admin .</a></li>
                                    <li><a href="#">20 jan 2019 .</a></li>
                                    <li><a href="#" class="corpo">Corporate</a></li>
                                </ul>
                            </div>
                            <h4><a href="/blog/making-distributed-team">Monthly Web Development Upto Cost Of JavaScript
                                    Ethics</a>
                            </h4>
                            <p>Lorem ipsum dolor sit amet consectetur adipisi
                                cing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <a href="/blog/making-distributed-team" class="btn blog-btn">Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="single-post mb-30 wow fadeInUp animated" data-animation="fadeInDown animated"
                        data-delay=".2s">
                        <div class="blog-thumb">
                            <a href="/blog/making-distributed-team"><img src="/site/img/blog/blog_img03.jpg"
                                    alt="img"></a>
                        </div>
                        <div class="blog-content">
                            <div class="b-meta mb-20">
                                <ul>
                                    <li><a href="#">By admin .</a></li>
                                    <li><a href="#">20 jan 2019 .</a></li>
                                    <li><a href="#" class="corpo">Corporate</a></li>
                                </ul>
                            </div>
                            <h4><a href="/blog/making-distributed-team">User Experience Psychology And Performance
                                    Smashing</a>
                            </h4>
                            <p>Lorem ipsum dolor sit amet consectetur adipisi
                                cing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <a href="/blog/making-distributed-team" class="btn blog-btn">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</x-site.layout>
